package pacote;


	public class Socio {
		
		private String nome;
		private String endereco;
		private String telefone;
		private String email;
		private int codigo; // C�digo so s�cio na Locadora
		
		
		public Socio() {
			
		}
		
		public int getCodigo() {
			return this.codigo;
		}
		
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getEndereco() {
			return endereco;
		}

		public void setEndereco(String endereco) {
			this.endereco = endereco;
		}

		public String getTelefone() {
			return telefone;
		}

		public void setTelefone(String telefone) {
			this.telefone = telefone;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}
		
		//public int registraSocio(List<Socio> listaDeSocios) {
		public int registraSocio() {
			try {
				this.codigo = ++Socio.ultimoCodigo;
				Socio.qtdeSocios++; // Soma um � qtde de s�cios registrados
				//listaDeSocios.add(this);
				return this.codigo;
			}
			catch (Exception e){
				return 0;
			}
		}
		
		/* Busca um s�cio pelo nome e retorna seu c�digo */
		public int consultaSocio(String nome) {
			for(Socio s: listaSocios) {
				if (s.getNome().contentEquals(nome)) {
					return listaSocios.indexOf(s);
				}
			}
			return -1;
		}
		
		public String mostraSocio() {
			String titulo = "*********** S�cio ***********";
			String nome = "Nome: " + this.getNome();
			String codigo = "C�digo: " + this.getCodigo();
			String tel = "Tel.: " + this.getTelefone();
			String email = "email: " + this.getEmail();
			String endereco = "End.: " + this.getEndereco();
			String socio = titulo + "\n" + 
			               codigo + "\n" + 
					       nome + "\n" +
			               tel + "\n" +
			               email + "\n" +
			               endereco + "\n" ;
			return socio  ;		
		}
		

	    /* Grava o objeto em um arquivo em Disco "socios.csv" */
		public boolean gravar() {
			try {
				FileOutputStream arquivo = new FileOutputStream("socios.csv", true);
				PrintWriter pr = new PrintWriter(arquivo);
				pr.println(this.getCodigo()+ ";" + this.getNome()+";"+this.getEndereco()+";"+this.getTelefone()+";"+this.getEmail());
				pr.close();
				arquivo.close();
				System.out.println("S�cio n� " + this.getCodigo() + " registrado com sucesso!!! uhuuu");
				return true;
			}
		    catch (Exception e){
		       	System.out.println("<<Gravar Socio>>: " + e.getMessage());
		       	return false;
			}
		}

		@Override
		public void consultar() {
			if (listaSocios.size()>0)
				for(Socio s: listaSocios)
					System.out.println(s.mostraSocio());
		}


		@Override
		public boolean cadastrar(Object o) {
			Socio socio = new Socio();
			socio = (Socio) o;
			try {
				registraSocio();
				if (!listaSocios.contains(socio))
				    listaSocios.add(socio);
				return true;
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				return false;
			}
			
		}
		
		public static void inicializaLista() {
			listaSocios = new ArrayList<>();
		}

		@Override
		public void excluir(int index) {
			if (index > 0)
			{
				try{			
					listaSocios.remove(index);
					System.out.println("S�cio exclu�do com sucesso!");
				}
				catch (Exception ex){
					System.out.println("<<Excluir Socio>>: " + ex.getMessage());
				}	
			}
		}

		public void ler() {

			try {
				FileInputStream arquivo = new FileInputStream("socios.csv");
				InputStreamReader input = new InputStreamReader(arquivo);
				BufferedReader br = new BufferedReader(input);
				String linha;
				
				do {
					linha = br.readLine();
					if (linha != null)
						System.out.println("Lido: " + linha);
					
				} while (linha != null);
				
			}
	        catch (Exception e){
	        	System.out.println("Erro ao ler o arquivo: " + e.getMessage());
	        }
			
		}
	}

